from django.contrib import admin
from django.urls import path
from . import views


urlpatterns = [

    path("", views.login_check, name=""),
    path("resister", views.register, name="register"),
    path("add_assessment", views.add_assessment, name="add_assessment"),
    path("delete_assessment", views.delete_assessment, name="delete_assessment"),
    path("edit_assessment", views.edit_assessment, name="edit_assessment"),
    path("logout", views.logout, name="logout")
   
   
    
]
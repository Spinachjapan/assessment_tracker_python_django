from django.db import models
from django.contrib.auth.models import User

#model for table of 'Assessments'

class Assessments(models.Model):

    username = models.ForeignKey( User,to_field='username', db_column='username', on_delete=models.CASCADE)
    title = models.CharField(max_length=50, null=False)
    due_date = models.DateField(null=False)
    content = models.CharField(max_length=410, null=True)

    def __str__(self):
        return str(self.title)

   
    
    class Meta:
        db_table = "Assessments"
 

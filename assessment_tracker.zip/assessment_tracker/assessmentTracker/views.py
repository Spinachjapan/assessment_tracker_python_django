from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import  render, redirect
from django.contrib.auth import login, authenticate 
from django.contrib.auth.forms import AuthenticationForm 
from django.http import HttpResponse, HttpResponseRedirect
from .models import Assessments
from django.contrib.auth.models import User


#first of all, check if cookie has a username-> main page directly or login requirement

def login_check(request):
  if request.COOKIES.get('username') != None:
     response = HttpResponse(render(request, 'main.html', {'assessment_list': Assessments.objects.filter(username = request.COOKIES.get('username')),
				 "m_range": [i for i in range(12)], "d_range": [t for t in range(31)]}))
     messages.info(request, f"Username: {request.COOKIES.get('username')}")
     return response
 
  else:
    return login_request(request)


# Login validation 

def login_request(request):
  if request.method == 'POST':
    form = AuthenticationForm(request, data=request.POST)
    if form.is_valid():
      username = form.cleaned_data.get('username')
      password = form.cleaned_data.get('password')
      user = authenticate(username=username, password=password)
      if user is not None:
        login(request, user)

        messages.info(request, f"Username: {username}")
        response = HttpResponse(render(request, 'main.html', {'assessment_list': Assessments.objects.filter(username = username),
				 "m_range": [i for i in range(12)], "d_range": [t for t in range(31)]}))
        
        if ('remember_me' in request.POST): #remember me selection
          response.set_cookie('username', username, max_age = 60 * 60 * 24 * 60)
        
        else:
          response.set_cookie('username', username, max_age= 60 * 60)

        return response
        
      else:
        messages.error(request,"Invalid username or password.")
    else:
      messages.error(request,"Invalid username or password.")
  form = AuthenticationForm()
  return render(request=request, template_name="login.html", context={"login_form":form})




# resister validation
def register(request):
    if request.method == 'POST':
        f = UserCreationForm(request.POST)
        if f.is_valid():
            f.save()
            messages.success(request, 'Account created successfully')
            return redirect("/")

    else:
        f = UserCreationForm()

    return render(request, 'register.html', {'form': f})







# add assessment 
def add_assessment(request):
	if request.method == 'POST':
		assessment = Assessments()
		user = User.objects.filter(username = request.COOKIES.get('username')).first()
		assessment.username = user
		assessment.due_date = request.POST['year'] + "-" + request.POST['month'] + "-" + request.POST['day']
		assessment.title = request.POST['title']
		assessment.content = request.POST['content']

		assessment.save()
		response = HttpResponse(render(request, 'main.html', {'assessment_list': Assessments.objects.filter(username = request.COOKIES.get('username')),
				 "m_range": [i for i in range(12)], "d_range": [t for t in range(31)]}))
		return response

# delete assessment
def delete_assessment(request):
	if request.method == 'POST':

		assessment = Assessments.objects.get(id=request.POST["id"])
		assessment.delete()
		response = HttpResponse(render(request, 'main.html', {'assessment_list': Assessments.objects.filter(username = request.COOKIES.get('username')),
				 "m_range": [i for i in range(12)], "d_range": [t for t in range(31)]}))
		return response


# edit assessment
def edit_assessment(request):
  
	if request.method == "POST":
    
		Assessments.objects.filter(id=request.POST["id"]).update(title=request.POST['title'], due_date=request.POST['year'] + "-" + request.POST['month'] + "-" + request.POST['day'], content=request.POST['content'])
		
		
		response = HttpResponse(render(request, 'main.html', {'assessment_list': Assessments.objects.filter(username = request.COOKIES.get('username')),
				 "m_range": [i for i in range(12)], "d_range": [t for t in range(31)]}))
		return response

# logout
def logout(request):

  response = HttpResponseRedirect('/')
  response.delete_cookie("username")  #delete cookies
  return response






	




  